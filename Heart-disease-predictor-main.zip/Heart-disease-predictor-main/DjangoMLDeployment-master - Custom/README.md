# Django ML Deployment

Learn the basics of Django required for ML Models. There are many concepts involved while learning Django, but specifically in this <a href="https://youtu.be/rNhVBv0i4os">tutorial</a> I teach
only what you require to get started with ML Model Deployment.

<hr>

Subscribe to my <a href="https://www.youtube.com/c/RaunakJoshi">YouTube</a> channel for similiar type of content.
